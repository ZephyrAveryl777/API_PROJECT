namespace BankApi.Exceptions;

public class InvalidLoginException : Exception
{

}