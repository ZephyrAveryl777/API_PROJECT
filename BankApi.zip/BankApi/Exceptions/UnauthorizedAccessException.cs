namespace BankApi.Exceptions;

public class UnauthorizedAccessException : Exception
{

}